#!/usr/bin/env python
# -*- coding: utf-8 -*-

import os
from libs import nmap
import tempfile
from libs.util import get_portable_path
import sys


def check_alive_by_nmap(config):
    current_function_name = sys._getframe().f_code.co_name
    # print('当前函数名为:', current_function_name) # check_live_by_nmap
    config[current_function_name] = []
    config.logger.info("[+] 开始通过{}模块进行检测存活IP!!!".format(current_function_name))
    config[current_function_name] = NmapCheckLiveHost(config).run()
    # 函数结果会返回到以当前函数名命名的config[]字典中。
    return config[current_function_name]


class NmapCheckLiveHost(object):
    # 获取存活主机列表
    def __init__(self, config):
        # 基本设置
        super(NmapCheckLiveHost, self).__init__()
        self.alive_host = list()
        self.logger = config.logger
        self.ip_list = config.ip_host

        # 程序设置
        self.program_name = "nmap"
        self.program_path = get_portable_path(config, self.program_name).replace("$BASE_DIR$", str(config.BASE_DIR))
        # self.logger.debug("[*]PATH {}: {}".format(self.program_name, self.program_path))
        self.check_live_options = config[self.program_name + '_' + 'check_live_options']

        # self.nmap_min_hostgroup = config.nmap_min_hostgroup
        # self.nmap_min_parallelism = config.nmap_min_parallelism
        # self.program_path = config.cpp_nmap_windows.replace("$BASE_DIR$", str(config.BASE_DIR))
        # 输出nmap相关的配置参数
        # config.logger.debug("[*]{}: {}".format('nmap_', config_key_with_prefix(config, 'nmap_')))
        # self.check_live_options = config.check_live_options.format(self.nmap_min_hostgroup, self.nmap_min_parallelism)

    def nmap_scan_alive(self):
        target_file_fp = tempfile.NamedTemporaryFile(prefix='nmap_alive_target_', suffix='.txt', delete=False)
        target_file_fp.write("\n".join(self.ip_list).encode("utf-8"))
        target_file_fp.close()
        # Windows下路径格式化,直接传入nmap会出现bug
        target_file_fp.name = target_file_fp.name.replace('\\', '\\\\')
        # self.logger.debug(target_file_fp.name)
        # nmap存活检测-基于icmp
        # nmap -sP -PI 192.168.1.1/24 -T4 # -PI 进行ping扫描
        # nmap ‐sn ‐PE ‐T4 192.168.1.0/24 # -PE与P0功能一样 无ping扫描
        # -iL 从已有的ip列表文件中读取并扫描
        # -sn 不进行端口扫描
        # -n  不做DNS解析
        # -R 总是做DNS反向解析
        # --min-hostgroup/max-hostgroup <size>：指定最小、最大的并行主机扫描组大小
        # --min-parallelism/max-parallelism <numprobes>：指定最小、最大并行探测数量
        # -oN/-oX/-oS/-oG <file>：分别输出正常、XML、s|

        # Warning: The -sP option is deprecated. Please use -sn

        # 不同版本的输出XML结果可能不同,目前nmap.py已修改适配 Nmap version 7.91 windows
        try:
            nmap_search_path = (
                self.program_path, 'nmap', '/usr/bin/nmap', '/usr/local/bin/nmap', '/sw/bin/nmap',
                '/opt/local/bin/nmap')
            nmap_scan = nmap.PortScanner(nmap_search_path=nmap_search_path)
            self.logger.debug("[*]{} -oX - {} -iL {}".format(self.program_path, self.check_live_options, target_file_fp.name))

            nmap_scan.scan(self.check_live_options,
                           arguments="-iL {tmp_target_file}".format(tmp_target_file=target_file_fp.name))
            # self.logger.debug("[*]{} program_command: {}".format(self.program_path, nmap_scan.command_line()))
            for host in nmap_scan.all_hosts():
                if nmap_scan[host]["status"]["state"] == "up":
                    self.alive_host.append(host)
        except KeyboardInterrupt:
            self.logger.error("[-]User aborted.")
            exit(0)
        except Exception as e:
            self.logger.error(str(e))
        finally:
            os.unlink(target_file_fp.name)
        self.logger.info(
            "[*] Nmap Scan Live Result ： All destination_ips: {}, live destination_ips: {}".format(len(self.ip_list),
                                                                                                   len(
                                                                                                       self.alive_host)))

    def run(self):
        # 检测存活主机
        # self.logger.info("[+] Check Live Host By Nmap...")
        self.nmap_scan_alive()
        return self.alive_host
