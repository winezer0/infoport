#!/usr/bin/env python
# -*- coding: utf-8 -*-
'''
@Author: NOVASEC
@Mail: NOVASEC@email.com
@Date: 2020-06-12 12:28:42
@LastEditTime : 2020-06-13 01:36:14
'''

from libs.datatype import AttribDict

# module paths
paths = AttribDict()

# config
config = AttribDict()

data = AttribDict()

