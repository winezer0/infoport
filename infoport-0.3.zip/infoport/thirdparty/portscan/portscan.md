源码地址:
https://github.com/phil-fly/portScan 

选择原因:
多种IP格式支持
多种端口格式支持
支持指定扫描127.0.0.1

需要优化:
不支持直接扫描域名-最后考虑
不支持UDP扫描-可能考虑

使用命令
Usage of ./portScan:
  -file
    	Use file mode to specify ip address .
  -full
    	Scan all TCP and UDP ports in full scan mode. The default is off. By default, only common TCP ports are scanned.
  -ip string
    	IP to be scanned, supports three formats:
    	192.168.0.1 
    	192.168.0.1-8 
    	192.168.0.0/24
  -p string
    	Port to be scanned, supports three formats:
    	80
    	22,80 
    	22-65535,21
  -t int
    	Maximum number of threads (default 10000)
